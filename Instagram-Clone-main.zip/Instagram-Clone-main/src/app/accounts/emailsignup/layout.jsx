import React from "react";

export default function layout({ children }) {
  return <div className="flex justify-center">{children}</div>;
}
